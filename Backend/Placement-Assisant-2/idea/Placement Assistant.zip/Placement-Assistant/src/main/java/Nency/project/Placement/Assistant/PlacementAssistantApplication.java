package Nency.project.Placement.Assistant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementAssistantApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementAssistantApplication.class, args);
	}

}
